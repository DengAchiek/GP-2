USE CountyHospitalDB;

-- 4.1  Calculate total hospital revenue.
SELECT 
	SUM(amount_paid) AS Total_Hospital_Revenue 
FROM 
	Bills;
    
-- 4.2 Find patients with unpaid bills.
SELECT
	p.patient_id AS Patient_ID,
    CONCAT(p.first_name, ' ', p.last_name) AS Patient_Name,
    b.bill_id AS Bill_ID,
    b.total_amount AS Billed_Amount,
    b.amount_paid AS Amount_Paid,
    (b.total_amount - b.amount_paid) AS Outstanding_Balance,
    b.Payment_status AS Status
FROM 
	Bills b
JOIN 
	Appointments a ON b.appointment_id = a.appointment_id
JOIN 
	Patients p ON a.patient_id = p.patient_id
WHERE 
b.payment_status IN ('Pending', 'Partial');

-- 4.3 Calculate the average treatment cost.
SELECT 
    AVG(actual_cost) AS Avg_Administered_Treatment_Cost 
FROM 
    Appointment_Treatments;

-- 4.4 Find the department generating the highest revenue.
SELECT
	d.department_name AS Department,
    SUM(b.amount_paid) AS Department_Revenue
FROM
	Departments d
JOIN
	Doctors doc ON doc.department_id = d.department_id
JOIN
	Appointments a ON a.doctor_id = doc.doctor_id
JOIN
	Bills b ON b.appointment_id = a.appointment_id
GROUP BY
	d.department_id, d.department_name
ORDER BY
	Department_Revenue DESC
LIMIT 1;

-- 4.5 Display the ten highest bills.
SELECT
	b.bill_id AS Bill_ID,
    CONCAT(p.first_name, ' ', p.last_name) AS Patient_Name,
    b.total_amount AS Total_Amount
FROM
	Bills b
JOIN
	Appointments a ON b.appointment_id = a.appointment_id
JOIN
	Patients p ON a.patient_id = p.patient_id
ORDER BY
	b.total_amount DESC
LIMIT 10;




                        -- CHALLENGES (BOTH GROUPS) 

-- 1. Identify doctors who have not treated any patient.
SELECT
	doc.doctor_id AS Doctor_ID,
    CONCAT(doc.first_name, ' ', doc.last_name) AS Doctor_Name
FROM
	Doctors doc
LEFT JOIN
	Appointments a ON a.doctor_id = doc.doctor_id AND a.status = 'Completed'
WHERE
	a.appointment_id IS NULL;

-- 2. Find departments with below-average appointments.
SELECT
	d.department_name AS Department,
    COUNT(a.appointment_id) AS Appointment_Count
FROM
	Departments d
JOIN
	Doctors doc ON doc.department_id = d.department_id
JOIN
	Appointments a ON a.doctor_id = doc.doctor_id
GROUP BY
	d.department_id, d.department_name
HAVING
	COUNT(a.appointment_id) < (
		SELECT AVG(cnt) FROM (
			SELECT COUNT(*) AS cnt
			FROM Departments d2
			JOIN Doctors doc2 ON doc2.department_id = d2.department_id
			JOIN Appointments a2 ON a2.doctor_id = doc2.doctor_id
			GROUP BY d2.department_id
		) sub
	);

-- 3. Create a patient treatment history view.
CREATE OR REPLACE VIEW Patient_Treatment_History AS
SELECT
    p.patient_id,
    CONCAT(p.first_name, ' ', p.last_name) AS patient_name,
    a.appointment_id,
    a.appointment_date,
    CONCAT(doc.first_name, ' ', doc.last_name) AS doctor_name,
    t.treatment_name,
    at.diagnosis,
    at.actual_cost
FROM
	Patients p
JOIN
	Appointments a ON a.patient_id = p.patient_id
JOIN
	Doctors doc ON doc.doctor_id = a.doctor_id
JOIN
	Appointment_Treatments at ON at.appointment_id = a.appointment_id
JOIN
	Treatments t ON t.treatment_id = at.treatment_id;

SELECT * FROM Patient_Treatment_History;

-- 4. Calculate monthly revenue trends.
SELECT
	DATE_FORMAT(bill_date, '%Y-%m') AS Revenue_Month,
    SUM(amount_paid) AS Monthly_Revenue
FROM
	Bills
GROUP BY
	Revenue_Month
ORDER BY
	Revenue_Month;

-- 5. Identify repeat patients (five or more visits).
SELECT
	p.patient_id AS Patient_ID,
    CONCAT(p.first_name, ' ', p.last_name) AS Patient_Name,
    COUNT(a.appointment_id) AS Visit_Count
FROM
	Patients p
JOIN
	Appointments a ON a.patient_id = p.patient_id
GROUP BY
	p.patient_id, Patient_Name
HAVING
	COUNT(a.appointment_id) >= 5;

-- 6. Find the doctor with the highest average bill value.
SELECT
	doc.doctor_id AS Doctor_ID,
    CONCAT(doc.first_name, ' ', doc.last_name) AS Doctor_Name,
    AVG(b.total_amount) AS Avg_Bill_Value
FROM
	Doctors doc
JOIN
	Appointments a ON a.doctor_id = doc.doctor_id
JOIN
	Bills b ON b.appointment_id = a.appointment_id
GROUP BY
	doc.doctor_id, Doctor_Name
ORDER BY
	Avg_Bill_Value DESC
LIMIT 1;
