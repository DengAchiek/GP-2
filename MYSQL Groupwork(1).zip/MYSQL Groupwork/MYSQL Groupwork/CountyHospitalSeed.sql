USE CountyHospitalDB;


-- 1. Insert Departments 
INSERT INTO Departments (department_name, head_of_department, department_phone_number, email) VALUES
('Cardiology', 'Dr. Wanjiru Kamau', '0712345001', 'cardiology@countyhospital.co.ke'),
('Pediatrics', 'Dr. Achieng Omondi', '0712345002', 'pediatrics@countyhospital.co.ke'),
('Orthopedics', 'Dr. Kiprotich Rotich', '0712345003', 'orthopedics@countyhospital.co.ke'),
('General Surgery', 'Dr. Wambui Kariuki', '0712345004', 'surgery@countyhospital.co.ke'),
('Obstetrics & Gynaecology', 'Dr. Nyambura Gitau', '0712345005', 'obsgyn@countyhospital.co.ke');

-- 2. Insert Doctors
INSERT INTO Doctors (first_name, last_name, specialization, license_number, phone_number, email, department_id, hire_date, consultation_fee) VALUES
('Wanjiru', 'Kamau', 'Cardiologist', 'KMPDC-10234', '0722100001', 'wkamau@countyhospital.co.ke', 1, '2018-03-14', 3500.00),
('Otieno', 'Odhiambo', 'Cardiologist', 'KMPDC-10235', '0722100002', 'oodhiambo@countyhospital.co.ke', 1, '2020-06-01', 3000.00),
('Achieng', 'Omondi', 'Pediatrician', 'KMPDC-10236', '0722100003', 'aomondi@countyhospital.co.ke', 2, '2016-01-20', 2500.00),
('Njeri', 'Mwangi', 'Pediatrician', 'KMPDC-10237', '0722100004', 'nmwangi@countyhospital.co.ke', 2, '2021-09-10', 2200.00),
('Kiprotich', 'Rotich', 'Orthopedic Surgeon', 'KMPDC-10238', '0722100005', 'krotich@countyhospital.co.ke', 3, '2015-11-05', 4500.00),
('Chebet', 'Langat', 'Orthopedic Surgeon', 'KMPDC-10239', '0722100006', 'clangat@countyhospital.co.ke', 3, '2019-04-17', 4000.00),
('Wambui', 'Kariuki', 'General Surgeon', 'KMPDC-10240', '0722100007', 'wkariuki@countyhospital.co.ke', 4, '2014-07-23', 5000.00),
('Muthoni', 'Ndungu', 'General Surgeon', 'KMPDC-10241', '0722100008', 'mndungu@countyhospital.co.ke', 4, '2022-02-14', 4200.00),
('Nyambura', 'Gitau', 'Obstetrician/Gynaecologist', 'KMPDC-10242', '0722100009', 'ngitau@countyhospital.co.ke', 5, '2017-10-30', 3800.00),
('Wafula', 'Simiyu', 'Obstetrician/Gynaecologist', 'KMPDC-10243', '0722100010', 'wsimiyu@countyhospital.co.ke', 5, '2023-01-09', 3200.00);

-- 3. Insert Patients
INSERT INTO Patients (first_name, last_name, date_of_birth, gender, phone_number, email, registration_date) VALUES
('Brian', 'Kiptoo', '1990-05-12', 'Male', '0733200001', 'briankiptoo@gmail.com', '2023-01-15'),
('Faith', 'Wanjiku', '1985-11-23', 'Female', '0733200002', 'faithwanjiku@gmail.com', '2023-02-02'),
('Dennis', 'Mutua', '1978-02-09', 'Male', '0733200003', 'dennismutua@gmail.com', '2023-02-20'),
('Grace', 'Achieng', '1995-07-30', 'Female', '0733200004', 'graceachieng@gmail.com', '2023-03-05'),
('Samuel', 'Kiprop', '2001-09-18', 'Male', '0733200005', 'samuelkiprop@gmail.com', '2023-03-19'),
('Esther', 'Nafula', '1988-12-01', 'Female', '0733200006', 'esthernafula@gmail.com', '2023-04-11'),
('Peter', 'Wekesa', '1993-04-25', 'Male', '0733200007', 'peterwekesa@gmail.com', '2023-05-08'),
('Mercy', 'Chepkoech', '1999-06-14', 'Female', '0733200008', 'mercychepkoech@gmail.com', '2023-06-02'),
('John', 'Otieno', '1982-08-08', 'Male', '0733200009', 'johnotieno@gmail.com', '2023-06-27'),
('Lucy', 'Adhiambo', '1975-03-03', 'Female', '0733200010', 'lucyadhiambo@gmail.com', '2023-07-14');

-- 4. Insert Appointments
INSERT INTO Appointments (patient_id, doctor_id, appointment_date, appointment_time, status, reason) VALUES
(1, 1, '2026-06-01', '09:00:00', 'Completed', 'Chest pain evaluation'),
(2, 3, '2026-06-01', '10:00:00', 'Completed', 'Child fever check-up'),
(3, 5, '2026-06-02', '11:00:00', 'Completed', 'Knee pain after fall'),
(4, 9, '2026-06-02', '13:00:00', 'Completed', 'Routine antenatal check-up'),
(5, 7, '2026-06-03', '08:30:00', 'Completed', 'Appendicitis suspected'),
(6, 2, '2026-06-03', '14:00:00', 'Cancelled', 'Follow-up on hypertension'),
(7, 4, '2026-06-04', '09:30:00', 'Scheduled', 'Vaccination schedule'),
(8, 6, '2026-06-05', '10:30:00', 'Scheduled', 'Fracture review'),
(9, 8, '2026-06-05', '15:00:00', 'No-Show', 'Hernia consultation'),
(10, 10, '2026-06-06', '11:30:00', 'Scheduled', 'Prenatal ultrasound');

-- 5. Insert Bills (1:1 with Appointments, Consolidated Payment Data)
INSERT INTO Bills (appointment_id, bill_date, due_date, total_amount, amount_paid, payment_status, payment_method, payment_date) VALUES
(1, '2026-06-01', '2026-06-15', 6500.00, 6500.00, 'Paid', 'Mobile Money', '2026-06-01'),
(2, '2026-06-01', '2026-06-15', 2500.00, 2500.00, 'Paid', 'Cash', '2026-06-01'),
(3, '2026-06-02', '2026-06-16', 9000.00, 4000.00, 'Partial', 'Insurance', '2026-06-02'),
(4, '2026-06-02', '2026-06-16', 3800.00, 0.00, 'Pending', NULL, NULL),
(5, '2026-06-03', '2026-06-17', 25000.00, 15000.00, 'Partial', 'Card', '2026-06-05');

-- 6. Insert Treatments (Master Catalog Menu)
INSERT INTO Treatments (treatment_name, treatment_description, standard_cost) VALUES
('ECG (Electrocardiogram)', 'Heart rhythm and electrical activity test', 3000.00),
('Malaria Rapid Test', 'Rapid diagnostic test for malaria parasites', 500.00),
('X-Ray Imaging', 'Radiographic imaging of bones/joints', 2500.00),
('Obstetric Ultrasound', 'Ultrasound scan for pregnancy monitoring', 3800.00),
('Appendectomy', 'Surgical removal of the appendix', 25000.00),
('Plaster Cast Application', 'Casting for bone fractures', 4500.00),
('Blood Pressure Management Consult', 'Follow-up consult and medication review', 1500.00);

-- 7. Insert Appointment_Treatments (Junction Table Log)
INSERT INTO Appointment_Treatments (appointment_id, treatment_id, diagnosis, treatment_notes, actual_cost, notes) VALUES
(1, 1, 'Mild arrhythmia', 'ECG performed and reviewed', 3000.00, 'Advised follow-up in 3 months'),
(1, 7, 'Mild arrhythmia', 'Consultation and medication review', 1500.00, 'Started on low-dose beta blocker'),
(2, 2, 'Suspected malaria', 'Rapid diagnostic test administered', 500.00, 'Test came back negative; viral fever confirmed'),
(3, 3, 'Suspected fracture', 'X-ray of left knee', 2500.00, 'No fracture found, soft tissue injury'),
(3, 6, 'Soft tissue injury', 'Applied supportive cast', 4500.00, 'Review in 2 weeks'),
(4, 4, 'Routine pregnancy check', 'Ultrasound scan performed, 24 weeks', 3800.00, 'Fetal growth normal'),
(5, 5, 'Acute appendicitis', 'Emergency appendectomy performed', 25000.00, 'Patient recovering well post-op');