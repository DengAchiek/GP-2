CREATE DATABASE IF NOT EXISTS CountyHospitalDB;
USE CountyHospitalDB;

-- 1. Departments Table
CREATE TABLE Departments (
    department_id INT PRIMARY KEY AUTO_INCREMENT,
    department_name VARCHAR(50) NOT NULL,
    head_of_department VARCHAR(50) NOT NULL,
    department_phone_number VARCHAR(15) NOT NULL,
    email VARCHAR(100)
);

-- 2. Doctors Table
CREATE TABLE Doctors (
    doctor_id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    specialization VARCHAR(100) NOT NULL,
    license_number VARCHAR(50) NOT NULL UNIQUE,
    phone_number VARCHAR(15) NOT NULL,
    email VARCHAR(100),
    department_id INT,
    hire_date DATE NOT NULL,
    consultation_fee DECIMAL(10, 2) NOT NULL CHECK (consultation_fee >= 0),
    FOREIGN KEY (department_id) REFERENCES Departments(department_id) ON DELETE SET NULL
);

-- 3. Patients Table
CREATE TABLE Patients (
    patient_id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    date_of_birth DATE NOT NULL,
    gender ENUM('Male', 'Female', 'Other') NOT NULL,
    phone_number VARCHAR(15) NOT NULL,
    email VARCHAR(100),
    registration_date DATE NOT NULL
);

-- 4. Appointments Table
CREATE TABLE Appointments (
    appointment_id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    appointment_date DATE NOT NULL,
    appointment_time TIME NOT NULL,
    status ENUM('Scheduled', 'Completed', 'Cancelled', 'No-Show') DEFAULT 'Scheduled',
    reason VARCHAR(200),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES Patients(patient_id) ON DELETE RESTRICT, 
    FOREIGN KEY (doctor_id) REFERENCES Doctors(doctor_id) ON DELETE RESTRICT   
);

-- 5. Bills Table (Enforcing Strict 1:1 with Appointments)
CREATE TABLE Bills (
    bill_id INT PRIMARY KEY AUTO_INCREMENT,
    appointment_id INT NOT NULL UNIQUE, -- Unique constraint guarantees 1:1 mapping
    bill_date DATE NOT NULL,
    due_date DATE NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL DEFAULT 0.00 CHECK (total_amount >= 0),
    amount_paid DECIMAL(10, 2) DEFAULT 0.00 CHECK (amount_paid >= 0),
    payment_status ENUM('Pending', 'Partial', 'Paid') DEFAULT 'Pending',
    payment_method ENUM('Cash', 'Insurance', 'Card', 'Mobile Money', 'Other'),
    payment_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (appointment_id) REFERENCES Appointments(appointment_id) ON DELETE CASCADE,
    CONSTRAINT chk_payment_overflow CHECK (amount_paid <= total_amount)
);

-- 6. Treatments (Master Catalog)
CREATE TABLE Treatments (
    treatment_id INT PRIMARY KEY AUTO_INCREMENT,
    treatment_name VARCHAR(100) NOT NULL UNIQUE,
    treatment_description TEXT,
    standard_cost DECIMAL(10, 2) NOT NULL CHECK (standard_cost >= 0)
);

-- 7. Appointment_Treatments (Junction Table between Appointments and Treatement)
CREATE TABLE Appointment_Treatments (
    appointment_treatment_id INT PRIMARY KEY AUTO_INCREMENT,
    appointment_id INT NOT NULL,
    treatment_id INT NOT NULL,
    diagnosis VARCHAR(200),
    treatment_notes TEXT, -- Preserved your exact updated naming convention
    actual_cost DECIMAL(10, 2) NOT NULL CHECK (actual_cost >= 0),
    notes TEXT,
    FOREIGN KEY (appointment_id) REFERENCES Appointments(appointment_id) ON DELETE CASCADE,
    FOREIGN KEY (treatment_id) REFERENCES Treatments(treatment_id) ON DELETE RESTRICT
);

